<?php

namespace App\Controllers;

use App\Models\relayModel;
use App\Models\sensorModel;

class Pages extends BaseController
{
    protected $relayModel, $sensorModel;
    public function __construct()
    {
        $this->relayModel = new relayModel;
        $this->sensorModel = new sensorModel;
    }
    public function index(): string
    {
        $kwh = $this->sensorModel->orderBy('id', 'DESC')->limit(60)->find();
        $total = 0;
        $count = count($kwh);

        foreach ($kwh as $row) {
            $total += $row['watt'];
        }

        if ($count > 0) {
            $average = $total / 60;
        } else {
            $average = 0;
        }

        $biaya = $average * 1500;

        $data = [
            'relay' => $this->relayModel->orderBy('id', 'DESC')->limit(20)->find(),
            'lastRelay' => $this->relayModel->orderBy('id', 'DESC')->limit(1)->find(),
            'kwh' => number_format($average, 2),
            'biaya' => $biaya
        ];
        return view('index', $data);
    }

    public function report()
    {
        $data = [
            'relay' => $this->relayModel->orderBy('id', 'DESC')->findAll(),
            'sensor' => $this->sensorModel->orderBy('id', 'DESC')->limit(1)->find(),
        ];
        return view('report', $data);
    }
}
