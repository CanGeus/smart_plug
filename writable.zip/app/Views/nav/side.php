<nav class="sidebar sidebar-offcanvas" id="sidebar">
    <ul class="nav">
        <li class="nav-item">
            <a class="nav-link active" href="<?= base_url() ?> ">
                <span class="menu-title">Dashboard</span>
                <i class="mdi mdi-home menu-icon"></i>
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="<?= base_url() ?>Pages/report ">
                <span class="menu-title">Report</span>
                <i class="mdi mdi-checkbox-multiple-blank menu-icon"></i>
            </a>
        </li>
    </ul>
</nav>